# Bot affitti Pesaro → Telegram

Controlla ogni 5 minuti i siti di otto agenzie immobiliari di Pesaro e invia su Telegram i nuovi annunci residenziali. Il primo controllo registra gli annunci esistenti senza notificarli; in seguito vengono segnalate solo le nuove pubblicazioni.

## Agenzie monitorate

- Kimia Home Immobiliare
- Agenzia Holiday Home
- MT Casa
- Immobiliare Trieste Pesaro
- Falcioni Immobiliare
- Pesaro Case
- Andreani Casa
- Bicasa

Uffici, negozi, capannoni e altri immobili commerciali vengono esclusi.

## Configurazione Telegram

1. Su Telegram apri **@BotFather**, invia `/newbot` e segui le istruzioni. Copia il token ricevuto.
2. Apri il nuovo bot e premilo su **Avvia**, oppure inviagli `/start`.
3. Nel browser apri `https://api.telegram.org/botIL_TUO_TOKEN/getUpdates` e copia il numero dentro `message.chat.id`.
4. Nel repository GitHub apri **Settings → Secrets and variables → Actions → New repository secret** e crea:
   - `TELEGRAM_BOT_TOKEN` con il token di BotFather;
   - `TELEGRAM_CHAT_ID` con il numero della chat.

Non inserire mai il token direttamente nei file del progetto.

## Avvio e test

Apri **Actions → Controlla affitti Pesaro → Run workflow**, abilita **Invia solo un messaggio Telegram di prova** e avvia. Dovresti ricevere subito il messaggio di conferma.

Avvia poi una seconda volta senza abilitare il test. Questa prima scansione salva gli annunci già presenti senza inviarli. Da quel momento il controllo parte automaticamente ogni 5 minuti.

GitHub può avviare i workflow programmati con qualche minuto di ritardo nei momenti di traffico elevato.

## Prova locale facoltativa

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python monitor.py --dry-run
```

Per Windows PowerShell, l'attivazione è `.venv\\Scripts\\Activate.ps1`.

## Manutenzione

Se un sito cambia struttura, il monitor invia un avviso dopo tre controlli falliti. Gli estrattori sono centralizzati in `monitor.py`, nella costante `SITES`.
